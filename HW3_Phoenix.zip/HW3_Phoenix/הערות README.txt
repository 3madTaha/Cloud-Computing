=====================================================
IMPORTANT NOTES ABOUT THE PROJECT
=====================================================

1. The chatbot API key is not included in the Colab notebook or in the GitHub repository.

GitHub automatically detects and blocks publicly exposed API keys for security reasons. Therefore, the Gemini API key is stored separately and is not included in the uploaded source code.

To activate the chatbot, open the following cell in the notebook:

🤖 Chatbot

Then replace:

GEMINI_API_KEY = "API KEY IS IN HW3_Phoenix.ZIP --> Links"

with the actual API key provided in the "Links" file located in the submission folder.

After updating the API key, re-run the cell and the chatbot will function normally.

-----------------------------------------------------

2. The system demonstration video is stored on Google Drive.

A link to view and download the video is provided in the "Links" file included with the submission.

-----------------------------------------------------

3. All submission-related links are centralized in the "Links" file.

The file contains:
- GitHub Repository Link
- Google Colab Notebook Link
- System Demonstration Video Link
- Gemini API Key

=====================================================
Phoenix Team
Smart Tomato Care System
=====================================================